# CEP App — React Native + TypeScript + ViaCEP

Aplicativo mobile que permite digitar um CEP, consultar o endereço na API
pública [ViaCEP](https://viacep.com.br/) via Axios e exibir o resultado em
um componente isolado.

## Stack

- React Native (Expo, managed workflow)
- TypeScript
- Axios

## Estrutura de pastas

```
src/
├── components/
│   └── AddressInfo/
│       ├── index.tsx     # renderiza o endereço recebido via props
│       └── styles.ts     # estilos exclusivos do componente
├── services/
│   └── api.ts             # instância do Axios com baseURL do ViaCEP
├── screens/
│   └── Home/
│       ├── index.tsx      # input, botão, loading e chamada à API
│       └── styles.ts      # estilos exclusivos da tela
└── types/
    └── cep.ts              # interface ViaCEPResponse
```

## Como rodar

```bash
npm install
npm start
```

Depois abra no Expo Go (Android/iOS) escaneando o QR code, ou rode `npm run
web` / `npm run android` / `npm run ios` conforme seu ambiente.

## Como os critérios de aceitação foram atendidos

- **CA01** — `Home/index.tsx` filtra o texto digitado para apenas dígitos,
  limita a 8 caracteres e `handleSearch` retorna cedo (sem chamar a API) se
  `cep.length !== 8`.
- **CA02** — `loading` vira `true` assim que o botão é pressionado e só
  volta a `false` no bloco `finally`, depois que a resposta (sucesso ou
  erro) foi processada.
- **CA03** — o botão de busca usa `isButtonDisabled` (`loading` ou CEP
  incompleto) tanto para desabilitar quanto para estilizar visualmente,
  evitando cliques duplicados durante uma requisição em andamento.
- **CA04** — `AddressInfo` é um componente separado que só recebe dados via
  props (`address`) e não faz nenhuma chamada de rede.
- **CA05** — nenhum `index.tsx` contém `StyleSheet.create`; todo estilo
  está em `styles.ts` na mesma pasta do componente/tela.
- **CA06** — o repositório deve ser publicado no GitHub com o histórico de
  commits abaixo (veja seção "Versionamento").

## Tratamento de erros

- Erros de rede (sem internet, timeout, etc.) caem no `catch` do
  `handleSearch` e exibem uma mensagem genérica de erro.
- CEPs com formato válido mas inexistentes na base do ViaCEP retornam
  `{ erro: true }` com HTTP 200; esse caso é tratado explicitamente antes de
  atualizar o estado do endereço.

## Versionamento

Este projeto já foi inicializado com `git init` e possui commits separados
representando a evolução do trabalho:

1. `Estrutura inicial do projeto Expo + TypeScript`
2. `Integração do Axios com a API ViaCEP`
3. `Componentização do AddressInfo e separação de estilos`

Para publicar no GitHub:

```bash
git remote add origin <URL_DO_SEU_REPOSITORIO>
git branch -M main
git push -u origin main
```
