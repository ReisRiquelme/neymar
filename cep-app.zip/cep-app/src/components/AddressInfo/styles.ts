import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginTop: 24,
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#F2F4F7',
    borderWidth: 1,
    borderColor: '#E1E4E8',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  label: {
    width: 90,
    fontSize: 14,
    fontWeight: '700',
    color: '#333333',
  },
  value: {
    flex: 1,
    fontSize: 14,
    color: '#333333',
  },
  cepTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
    color: '#1A1A1A',
  },
});
