import React from 'react';
import { View, Text } from 'react-native';
import { ViaCEPResponse } from '../../types/cep';
import { styles } from './styles';

interface AddressInfoProps {
  address: ViaCEPResponse | null;
}

// Componente "burro" (apresentacional): recebe o endereço já resolvido via
// props e apenas renderiza. Não faz nenhuma chamada à API nem guarda estado.
export function AddressInfo({ address }: AddressInfoProps) {
  // Enquanto nenhum CEP válido foi consultado, o componente não renderiza nada.
  if (!address) {
    return null;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.cepTitle}>CEP: {address.cep}</Text>

      <View style={styles.row}>
        <Text style={styles.label}>Rua:</Text>
        <Text style={styles.value}>{address.logradouro || '-'}</Text>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>Bairro:</Text>
        <Text style={styles.value}>{address.bairro || '-'}</Text>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>Cidade:</Text>
        <Text style={styles.value}>{address.localidade || '-'}</Text>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>UF:</Text>
        <Text style={styles.value}>{address.uf || '-'}</Text>
      </View>

      {!!address.complemento && (
        <View style={styles.row}>
          <Text style={styles.label}>Complemento:</Text>
          <Text style={styles.value}>{address.complemento}</Text>
        </View>
      )}
    </View>
  );
}
