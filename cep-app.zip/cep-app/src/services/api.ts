import axios from 'axios';

// Instância isolada do Axios com a baseURL da API pública ViaCEP.
// Manter a configuração de rede centralizada aqui facilita reaproveitar
// interceptors, timeouts e headers em qualquer outra tela do app.
export const api = axios.create({
  baseURL: 'https://viacep.com.br/ws/',
  timeout: 10000,
});
