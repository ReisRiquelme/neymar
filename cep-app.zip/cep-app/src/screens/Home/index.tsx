import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { api } from '../../services/api';
import { ViaCEPResponse } from '../../types/cep';
import { AddressInfo } from '../../components/AddressInfo';
import { styles } from './styles';

const CEP_LENGTH = 8;

export function Home() {
  const [cep, setCep] = useState('');
  const [address, setAddress] = useState<ViaCEPResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // CA01: aceita apenas dígitos e limita a 8 caracteres.
  function handleChangeCep(text: string) {
    const onlyDigits = text.replace(/[^0-9]/g, '').slice(0, CEP_LENGTH);
    setCep(onlyDigits);

    // Ao editar o campo, limpamos resultado/erro anteriores para não exibir
    // dados de uma busca antiga junto de um CEP diferente sendo digitado.
    if (errorMessage) setErrorMessage(null);
  }

  const handleSearch = useCallback(async () => {
    // CA01: não dispara a busca se o campo estiver incompleto ou vazio.
    if (cep.length !== CEP_LENGTH) {
      setErrorMessage('Digite um CEP válido com 8 dígitos.');
      return;
    }

    setErrorMessage(null);
    setAddress(null);
    setLoading(true); // CA02: loading aparece imediatamente ao clicar

    try {
      const response = await api.get<ViaCEPResponse>(`${cep}/json/`);

      // A API ViaCEP responde 200 OK mesmo para CEPs inexistentes,
      // sinalizando o problema através do campo "erro".
      if (response.data.erro) {
        setErrorMessage('CEP não encontrado. Verifique o número digitado.');
        setAddress(null);
      } else {
        setAddress(response.data);
      }
    } catch (error) {
      setErrorMessage('Não foi possível buscar o CEP. Verifique sua conexão e tente novamente.');
      setAddress(null);
    } finally {
      setLoading(false); // CA02: loading só some após a resposta ser processada
    }
  }, [cep]);

  const isButtonDisabled = loading || cep.length !== CEP_LENGTH;

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>Buscador de CEP</Text>
          <Text style={styles.subtitle}>
            Digite um CEP para consultar o endereço na base do ViaCEP.
          </Text>

          <View style={styles.inputRow}>
            <TextInput
              style={styles.input}
              placeholder="00000000"
              keyboardType="numeric"
              maxLength={CEP_LENGTH}
              value={cep}
              onChangeText={handleChangeCep}
              editable={!loading}
            />

            {/* CA03: botão desabilitado durante o loading, evitando requisições duplicadas */}
            <TouchableOpacity
              style={[styles.button, isButtonDisabled && styles.buttonDisabled]}
              onPress={handleSearch}
              disabled={isButtonDisabled}
            >
              <Text style={styles.buttonText}>Buscar</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.helperText}>{cep.length}/{CEP_LENGTH} dígitos</Text>

          {loading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#2563EB" />
            </View>
          )}

          {!loading && errorMessage && <Text style={styles.errorText}>{errorMessage}</Text>}

          {!loading && <AddressInfo address={address} />}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
